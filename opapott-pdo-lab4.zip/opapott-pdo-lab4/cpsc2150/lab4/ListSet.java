package cpsc2150.lab4;

import java.util.*;

/**
 * @invariants 0 <= listset.size <= MAX_SIZE
 * correspondence size_of_list = list.getSize()
 */
public class ListSet implements ISet{

    private List<Integer> listset;

    ListSet(){
        listset = new ArrayList<Integer>();
    }

    public void add(Integer val){
        listset.add(val);
    }

    public Integer removePos(int pos){

        Integer num = listset.get(pos);
        listset.remove(pos);

        return num;

    }

    public boolean contains(Integer val){

        for(int i = 0; i < listset.size(); i++){
            int num = listset.get(i);

            if(num == val){return true;}

        }
        return false;

    }

    public int getSize(){

        return listset.size();

    }

    public boolean isEmpty(){
        return listset.isEmpty();
    }

    /**
     *
     * @return a string with a representation of the set
     * @post toString = ""
     */
    @Override
    public String toString(){

        String s = new String();

        for(int i = 0; i < listset.size(); i++){
            if(listset.get(i) == null){
                break;
            }else {
                s += listset.get(i) + ", ";
            }
        }

        return s;

    }


}
