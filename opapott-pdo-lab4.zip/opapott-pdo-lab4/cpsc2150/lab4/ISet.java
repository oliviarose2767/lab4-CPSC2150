package cpsc2150.lab4;

public interface ISet {

    /**
     *
     * @param val is the value to be
     *            added to the set
     * @pre
     * MIN_VALUE < val < MAX_VALUE
     * @post
     *
     */
    void add(Integer val);

    /**
     *
     * @param pos is a position in the set
     * @return the value removed
     * @pre
     * pos > 0 && getSize() != 0
     * @post
     */
    Integer removePos(int pos);

    /**
     *
     * @param val, a value supposedly in set
     * @return returns true if int val is
     *         present in the set
     * @pre
     * val is a valid input int
     * @post
     * true or false will be returned
     */
    boolean contains(Integer val);

    /**
     *
     * @return returns the size of the set
     * @pre
     * none
     * @post
     * 0 <= return <= 100
     */
    int getSize();

    /**
     * @pre unionWith.size() != 0
     * @post unionWith.size >= 1
     */
    default void union(ISet unionWith){

        Integer temp = 0;

        for(int i = 0; i < unionWith.getSize(); i++ ){
            temp = unionWith.removePos(0);
            if(!this.contains(temp)){
                this.add(temp);
            }
        }

    }

    /**
     * @pre intWith.size() != 0
     * @post unionWith.size >= 1
     */
    default void intersect(ISet intWith){

        Integer temp = 0;

        for(int i = 0; i < intWith.getSize(); i++){
            temp = intWith.removePos(0);
            if(this.contains(temp) && intWith.contains(temp)){
                this.add(temp);
            }
        }

    }

    /**
     * @pre diffWith.size() >= 0
     * @post diffWith.size() >= 1
     */
    default void difference(ISet diffWith){

       /* temp list contains values inside 'this', but not in diffWith.
           get the values, then delete from this then add all elements of
           temp list to this.

         */
        ISet result = (ISet) new ArraySet();
        for(int i = 0; i <= diffWith.getSize(); i++ )
        {
            Integer tempValue = diffWith.removePos(0);

            if(!this.contains(tempValue)){
                result.add(tempValue);

            }else if(this.contains(tempValue)){


            }
        }

        //Removing all values in this
        for(int i = 0; i <= this.getSize(); i++ )
        {
            Integer element = this.removePos(0);

        }

        for(int i = 0; i <= result.getSize(); i++ )
        {
            Integer element = result.removePos(0);
            this.add(element);
        }

    }

}
