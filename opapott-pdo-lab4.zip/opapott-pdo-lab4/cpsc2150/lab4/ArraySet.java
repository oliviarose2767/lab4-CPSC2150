package cpsc2150.lab4;

/**
 * @invariants 0 <= arr.size <= MAX_SIZE
 * correspondence size_of_array = arr.getSize()
 */
public class ArraySet implements ISet{

    private static int MAX_SIZE = 100;

    private Integer[] arr = new Integer[MAX_SIZE];

    public ArraySet(){}

    public void add(Integer val) {

        for(int i = 0; i < arr.length; i++){
            if(arr[i] == null){
                arr[i] = val;
                break;
            }
        }

    }

    public Integer removePos(int pos) {

        Integer removed = arr[pos];

        for(int i = pos; i < arr.length - 1; i++){
            arr[i] = arr[i + 1];
        }

        return removed;

    }

    public boolean contains(Integer val) {

        boolean contains = false;

        for(int i = 0; i < arr.length; i++){
            if(arr[i] == val){
                contains = true;
            }
        }

        return contains;

    }

    public int getSize() {

        int size = 0;

        for(int i = 0; i < arr.length; i++){
            if(arr[i] != null){
                size++;
            }
        }

        return size;

    }

    public boolean isEmpty(){

        boolean empty = true;

        for(int i = 0; i < MAX_SIZE; i++){
            if(arr[i] != null){
                empty = false;
            }
        }

        return empty;

    }

    @Override
    public String toString(){

        String s = new String();
        for(int i = 0; i < arr.length; i++){
            if(arr[i] == null){
                break;
            }else {
                s += arr[i] + ", ";
            }
        }

        return s;

    }

}
